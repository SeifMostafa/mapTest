package mobile;

public class SelectionListener {
    public SelectionListener() {
        super();
    }
}
